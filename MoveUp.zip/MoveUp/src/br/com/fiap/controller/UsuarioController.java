package br.com.fiap.controller;

import br.com.fiap.model.dao.ConnectionFactory;
import br.com.fiap.model.dao.UsuarioDAO;
import br.com.fiap.model.dto.Usuario;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class UsuarioController {

    //método de cadastro
    public String inserirUsuario(int idUsuario,  String nomeUsuario, String cpf, String email,String telefone,String senha, String cidade, String bairro, String rua, String numeroResidencia,int pontosDisponiveis,int pontosUtilizados, int quantidadePassagem ) throws ClassNotFoundException, SQLException {
        String resultado;
        Connection con = ConnectionFactory.abrirConexao();
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(idUsuario);
        usuario.setNomeUsuario(nomeUsuario);
        usuario.setCpf(cpf);
        usuario.setEmail(email);
        usuario.setTelefone(telefone);
        usuario.setSenha(senha);
        usuario.setCidade(cidade);
        usuario.setBairro(bairro);
        usuario.setRua(rua);
        usuario.setNumeroResidencia(numeroResidencia);
        usuario.setPontosDisponiveis(pontosDisponiveis);
        usuario.setPontosUtilizados(pontosUtilizados);
        usuario.setQuantidadePassagem(quantidadePassagem);
        UsuarioDAO usuarioDAO = new UsuarioDAO(con);
        resultado = usuarioDAO.inserir(usuario);
        ConnectionFactory.fecharConexao(con);
        return resultado;
    }

    /// método de alteração
    public String alterarUsuario(int idUsuario,  String nomeUsuario, String cpf, String email,String telefone,String senha, String cidade, String bairro, String rua, String numeroResidencia,int pontosDisponiveis,int pontosUtilizados, int quantidadePassagem ) throws ClassNotFoundException, SQLException {
        String resultado;
        Connection con = ConnectionFactory.abrirConexao();
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(idUsuario);
        usuario.setNomeUsuario(nomeUsuario);
        usuario.setCpf(cpf);
        usuario.setEmail(email);
        usuario.setTelefone(telefone);
        usuario.setSenha(senha);
        usuario.setCidade(cidade);
        usuario.setBairro(bairro);
        usuario.setRua(rua);
        usuario.setNumeroResidencia(numeroResidencia);
        usuario.setPontosDisponiveis(pontosDisponiveis);
        usuario.setPontosUtilizados(pontosUtilizados);
        usuario.setQuantidadePassagem(quantidadePassagem);
        UsuarioDAO usuarioDAO = new UsuarioDAO(con);
        resultado = usuarioDAO.alterar(usuario);
        ConnectionFactory.fecharConexao(con);
        return resultado;
    }

    //método de exclusão
    public String excluirUsuario(int idUsuario,  String nomeUsuario, String cpf, String email,String telefone,String senha, String cidade, String bairro, String rua, String numeroResidencia,int pontosDisponiveis,int pontosUtilizados, int quantidadePassagem ) throws ClassNotFoundException, SQLException {
        String resultado;
        Connection con = ConnectionFactory.abrirConexao();
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(idUsuario);
        usuario.setNomeUsuario(nomeUsuario);
        usuario.setCpf(cpf);
        usuario.setEmail(email);
        usuario.setTelefone(telefone);
        usuario.setSenha(senha);
        usuario.setCidade(cidade);
        usuario.setBairro(bairro);
        usuario.setRua(rua);
        usuario.setNumeroResidencia(numeroResidencia);
        usuario.setPontosDisponiveis(pontosDisponiveis);
        usuario.setPontosUtilizados(pontosUtilizados);
        usuario.setQuantidadePassagem(quantidadePassagem);
        UsuarioDAO usuarioDAO = new UsuarioDAO(con);
        resultado = usuarioDAO.excluir(usuario);
        ConnectionFactory.fecharConexao(con);
        return resultado;
    }

    //método de leitura
    public ArrayList<Usuario> listarTodos() throws ClassNotFoundException, SQLException{
        Connection con = ConnectionFactory.abrirConexao();
        UsuarioDAO usuarioDAO = new UsuarioDAO(con);
        ArrayList<Usuario> lista = usuarioDAO.listarTodos();
        ConnectionFactory.fecharConexao(con);
        return lista;
    }

    //métodos de consulta
    public int consultarPontos(Usuario usuario) {
        return usuario.getPontosDisponiveis();
    }

    public int consultarPontosUtilizados(Usuario usuario) {
        return usuario.getPontosUtilizados();
    }

    public int consultarPassagens(Usuario usuario) {
        return usuario.getQuantidadePassagem();
    }
}

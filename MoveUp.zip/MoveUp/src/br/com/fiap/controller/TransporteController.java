package br.com.fiap.controller;

import br.com.fiap.model.dto.Transporte;

import java.time.LocalDate;

public class TransporteController {



    // métodos de conversão
    public void converterOnibus(Transporte transporte) {

        transporte.setQuantidadePassagem(1);
        transporte.setPontosUtilizados(589);
        transporte.setStatus("Ativo");
        transporte.setDataGeracao(LocalDate.now());
    }

    public void converterMetroETrem(Transporte transporte) {

        transporte.setQuantidadePassagem(1);
        transporte.setPontosUtilizados(600);
        transporte.setStatus("Ativo");
        transporte.setDataGeracao(LocalDate.now());
    }}

package br.com.fiap.model.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class  Missao {
    private String descricao;
    private String tipoTransporte;
    private int pontosGerados;
    private int pontosDisponiveis;
    private LocalDate dataAtividade;

    //construtores
    public Missao(){

    }

    public Missao(String descricao, String tipoTransporte, int pontosGerados, int pontosDisponiveis, LocalDate dataAtividade){
        setDescricao(descricao);
        setTipoTransporte(tipoTransporte);
        setPontosGerados(pontosGerados);
        setPontosDisponiveis(pontosDisponiveis);
        setDataAtividade(dataAtividade);
    }

    // métodos getters/setters

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipoTransporte() {
        return tipoTransporte;
    }

    public void setTipoTransporte(String tipoTransporte) {
        this.tipoTransporte = tipoTransporte;
    }

    public int getPontosGerados() {
        return pontosGerados;
    }

    public void setPontosGerados(int pontosGerados) {
        this.pontosGerados = pontosGerados;
    }

    public int getPontosDisponiveis() {
        return pontosDisponiveis;
    }

    public void setPontosDisponiveis(int pontosDisponiveis) {
        this.pontosDisponiveis = pontosDisponiveis;
    }

    public LocalDate getDataAtividade() {
        return dataAtividade;
    }

    public void setDataAtividade(LocalDate dataAtividade) {
        this.dataAtividade = dataAtividade;
    }
}

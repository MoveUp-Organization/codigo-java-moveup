package br.com.fiap.model.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Voucher {
    private int quantidadePassagem;
    private LocalDate dataGeracao;
    private String status;
    private int pontosUtilizados;

    //construtor
    public Voucher(){
        setDataGeracao(LocalDate.now());
        setStatus("Aguardando ativação");

    }

    public Voucher(int quantidadePassagem, LocalDate dataGeracao, String status, int pontosUtilizados){
        setQuantidadePassagem(quantidadePassagem);
        setDataGeracao(dataGeracao);
        setStatus(status);
        setPontosUtilizados(pontosUtilizados);
    }

    //métodos getters/setters

    public int getQuantidadePassagem() {
        return quantidadePassagem;
    }

    public void setQuantidadePassagem(int quantidadePassagem) {
        this.quantidadePassagem = quantidadePassagem;
    }

    public LocalDate getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(LocalDate dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getPontosUtilizados() {
        return pontosUtilizados;
    }

    public void setPontosUtilizados(int pontosUtilizados) {
        this.pontosUtilizados = pontosUtilizados;
    }
}

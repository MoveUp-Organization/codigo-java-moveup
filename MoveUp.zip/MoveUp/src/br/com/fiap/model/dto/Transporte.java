package br.com.fiap.model.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Transporte {
    //atributos
    private int idTransporte;
    private String descricao;
    private String tipoTransporte;
    private LocalDate dataGeracao;
    private String status;
    private int pontosGerados;
    private int quantidadePassagem;
    private int pontosUtilizados;
    private int pontosDisponiveis;

    //construtores
    public Transporte(){

    }

    public Transporte(int idTransporte,String descricao, String tipoTransporte, int pontosGerados, LocalDate dataGeracao, String status ,int quantidadePassagem, int pontosUtilizados, int pontosDisponiveis){
        setIdTransporte(idTransporte);
        setDescricao(descricao);
        setTipoTransporte(tipoTransporte);
        setPontosGerados(pontosGerados);
        setDataGeracao(dataGeracao);
        setStatus(status);
        setQuantidadePassagem(quantidadePassagem);
        setPontosUtilizados(pontosUtilizados);
        setPontosDisponiveis(pontosDisponiveis);
    }

    // métodos getters/setters


    public int getIdTransporte() {
        return idTransporte;
    }

    public void setIdTransporte(int idTransporte) {
        this.idTransporte = idTransporte;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipoTransporte() {
        return tipoTransporte;
    }

    public void setTipoTransporte(String tipoTransporte) {
        this.tipoTransporte = tipoTransporte;
    }

    public int getPontosGerados() {
        return pontosGerados;
    }

    public void setPontosGerados(int pontosGerados) {
        this.pontosGerados = pontosGerados;
    }

    public LocalDate getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(LocalDate dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getQuantidadePassagem() {
        return quantidadePassagem;
    }

    public void setQuantidadePassagem(int quantidadePassagem) {
        this.quantidadePassagem = quantidadePassagem;
    }

    public int getPontosUtilizados() {
        return pontosUtilizados;
    }

    public void setPontosUtilizados(int pontosUtilizados) {
        this.pontosUtilizados = pontosUtilizados;
    }

    public int getPontosDisponiveis() {
        return pontosDisponiveis;
    }

    public void setPontosDisponiveis(int pontosDisponiveis) {
        this.pontosDisponiveis = pontosDisponiveis;
    }

}

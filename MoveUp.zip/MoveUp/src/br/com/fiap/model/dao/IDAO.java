package br.com.fiap.model.dao;

import br.com.fiap.model.dto.Usuario;

import java.util.ArrayList;

public interface IDAO {
    public String inserir (Usuario usuario);
    public String alterar (Usuario usuario);
    public String excluir (Usuario usuario);
    public ArrayList<Usuario> listarTodos();
}

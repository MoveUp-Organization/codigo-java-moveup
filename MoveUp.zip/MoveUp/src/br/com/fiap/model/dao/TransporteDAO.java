package br.com.fiap.model.dao;

import br.com.fiap.model.dto.Transporte;
import br.com.fiap.model.dto.Usuario;
import oracle.sql.DATE;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TransporteDAO {
    private Connection con;
    private Transporte transporte;

    //construtor
    public TransporteDAO(Connection con) {
        this.con = con;
    }

    //getters/setters
    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

    //métodos de inserir
    public String inserir(Transporte transporte) {
        String sql = "insert into ddd_transporte( descricao, tipo_transporte, data_geracao, status, pontos_gerados, quantidade_passagem, pontos_utilizados, pontos_disponiveis ) values(?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getCon().prepareStatement(sql)) {
            ps.setString(1, transporte.getDescricao());
            ps.setString(2, transporte.getTipoTransporte());
            ps.setDate(3, Date.valueOf(transporte.getDataGeracao()));
            ps.setString(4, transporte.getStatus());
            ps.setInt(5, transporte.getPontosGerados());
            ps.setInt(6, transporte.getQuantidadePassagem());
            ps.setInt(7, transporte.getPontosUtilizados());
            ps.setInt(8, transporte.getPontosDisponiveis());
            if (ps.executeUpdate() > 0) {
                return "Transporte inserido com sucesso.";
            } else {
                return "Erro ao inserir transporte";
            }

        } catch (SQLException e) {
            return "Erro de SQL: " + e.getMessage();
        }
    }


    public String alterar(Transporte transporte) {

        String sql = "update ddd_transporte set descricao = ?, tipo_transporte = ?, data_geracao = ?, status = ?, pontos_gerados = ?, quantidade_passagem = ?,pontos_utilizados = ?, pontos_disponiveis = ? where id_transporte = ?";

        try (PreparedStatement ps = getCon().prepareStatement(sql)) {

            ps.setString(1, transporte.getDescricao());
            ps.setString(2, transporte.getTipoTransporte());
            ps.setDate(3, Date.valueOf((transporte.getDataGeracao())));
            ps.setString(4, transporte.getStatus());
            ps.setInt(5, transporte.getPontosGerados());
            ps.setInt(6, transporte.getQuantidadePassagem());
            ps.setInt(7, transporte.getPontosUtilizados());
            ps.setInt(8, transporte.getPontosDisponiveis());
            ps.setInt(9, transporte.getIdTransporte());

            if (ps.executeUpdate() > 0) {
                return "Transporte alterado com sucesso.";
            } else {
                return "Erro ao alterar transporte.";
            }

        } catch (SQLException e) {
            return "Erro de SQL: " + e.getMessage();
        }
    }

    public ArrayList<Transporte> listarTodos() {

        String sql = "SELECT * FROM ddd_transporte ORDER BY id_transporte";

        ArrayList<Transporte> listaTransportes = new ArrayList<>();

        try (
                PreparedStatement ps = getCon().prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Transporte transporte = new Transporte();

                transporte.setIdTransporte(rs.getInt("id_transporte"));
                transporte.setDescricao(rs.getString("descricao"));
                transporte.setTipoTransporte(rs.getString("tipo_transporte"));
                transporte.setDataGeracao(
                        rs.getDate("data_geracao").toLocalDate()
                );
                transporte.setStatus(rs.getString("status"));
                transporte.setPontosGerados(rs.getInt("pontos_gerados"));
                transporte.setQuantidadePassagem(
                        rs.getInt("quantidade_passagem")
                );
                transporte.setPontosUtilizados(
                        rs.getInt("pontos_utilizados")
                );
                transporte.setPontosDisponiveis(
                        rs.getInt("pontos_disponiveis")
                );

                listaTransportes.add(transporte);
            }

            return listaTransportes;

        } catch (SQLException e) {
            System.out.println("Erro de SQL: " + e.getMessage());
            return null;
        }
    }











}
package br.com.fiap.view;

public class UsuarioView {
}
